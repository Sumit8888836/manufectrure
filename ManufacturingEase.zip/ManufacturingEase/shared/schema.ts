import { pgTable, text, serial, integer, boolean, timestamp, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
});

// Production Lines
export const productionLines = pgTable("production_lines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("stopped"),
  efficiency: real("efficiency"),
  productionRate: integer("production_rate"),
  currentJobId: integer("current_job_id"),
  nextMaintenance: timestamp("next_maintenance"),
});

export const insertProductionLineSchema = createInsertSchema(productionLines).pick({
  name: true,
  description: true,
  status: true,
  efficiency: true,
  productionRate: true,
  currentJobId: true,
  nextMaintenance: true,
});

// Equipment
export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default("stopped"),
  productionLineId: integer("production_line_id"),
  utilization: real("utilization"),
  runtime: real("runtime"),
  nextMaintenance: timestamp("next_maintenance"),
  errorMessage: text("error_message"),
});

export const insertEquipmentSchema = createInsertSchema(equipment).pick({
  name: true,
  type: true,
  status: true,
  productionLineId: true,
  utilization: true,
  runtime: true,
  nextMaintenance: true,
  errorMessage: true,
});

// Inventory Items
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sku: text("sku").notNull().unique(),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull().default(0),
  reorderLevel: integer("reorder_level"),
  unitCost: real("unit_cost"),
  location: text("location"),
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).pick({
  name: true,
  sku: true,
  category: true,
  quantity: true,
  reorderLevel: true,
  unitCost: true,
  location: true,
});

// Work Orders
export const workOrders = pgTable("work_orders", {
  id: serial("id").primaryKey(),
  orderId: text("order_id").notNull().unique(),
  product: text("product").notNull(),
  quantity: integer("quantity").notNull(),
  status: text("status").notNull().default("scheduled"),
  startDate: timestamp("start_date"),
  dueDate: timestamp("due_date"),
  progress: real("progress").default(0),
  assignedLineId: integer("assigned_line_id"),
});

export const insertWorkOrderSchema = createInsertSchema(workOrders).pick({
  orderId: true,
  product: true,
  quantity: true,
  status: true,
  startDate: true,
  dueDate: true,
  progress: true,
  assignedLineId: true,
});

// Production Metrics
export const productionMetrics = pgTable("production_metrics", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  lineId: integer("line_id").notNull(),
  oee: real("oee"), // Overall Equipment Effectiveness
  productionRate: integer("production_rate"),
  qualityRate: real("quality_rate"),
  downtime: integer("downtime"),
  unitsProduced: integer("units_produced"),
});

export const insertProductionMetricsSchema = createInsertSchema(productionMetrics).pick({
  date: true,
  lineId: true,
  oee: true,
  productionRate: true,
  qualityRate: true,
  downtime: true,
  unitsProduced: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ProductionLine = typeof productionLines.$inferSelect;
export type InsertProductionLine = z.infer<typeof insertProductionLineSchema>;

export type Equipment = typeof equipment.$inferSelect;
export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;

export type WorkOrder = typeof workOrders.$inferSelect;
export type InsertWorkOrder = z.infer<typeof insertWorkOrderSchema>;

export type ProductionMetric = typeof productionMetrics.$inferSelect;
export type InsertProductionMetric = z.infer<typeof insertProductionMetricsSchema>;
