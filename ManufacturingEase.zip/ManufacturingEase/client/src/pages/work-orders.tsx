import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { FilterIcon, RefreshCcw, PlusCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import WorkOrderTable from "@/components/dashboard/WorkOrderTable";
import { WorkOrder } from "@shared/schema";

export default function WorkOrders() {
  // Fetch work orders
  const { data: workOrders, isLoading } = useQuery<WorkOrder[]>({
    queryKey: ['/api/work-orders'],
  });
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Work Orders</h1>
          <p className="text-gray-500">Manage and track all manufacturing work orders</p>
        </div>
        <div className="flex gap-2">
          <Button>
            <PlusCircle size={16} className="mr-2" />
            Create Work Order
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Filter Work Orders</CardTitle>
          <CardDescription>
            Use the filters below to find specific work orders
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="w-full sm:w-auto">
              <Label htmlFor="search">Search</Label>
              <Input id="search" placeholder="Search by ID or product" className="mt-1" />
            </div>
            <div className="w-full sm:w-auto">
              <Label htmlFor="status-filter">Status</Label>
              <Select>
                <SelectTrigger className="mt-1 w-full" id="status-filter">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full sm:w-auto">
              <Label htmlFor="date-range">Date Range</Label>
              <Select>
                <SelectTrigger className="mt-1 w-full" id="date-range">
                  <SelectValue placeholder="All dates" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All dates</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This week</SelectItem>
                  <SelectItem value="month">This month</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full sm:w-auto mt-auto">
              <Button variant="outline" className="w-full sm:w-auto">
                <FilterIcon size={16} className="mr-2" />
                Apply Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-gray-500">
          {workOrders?.length || 0} work orders found
        </div>
        <Button variant="outline" size="sm">
          <RefreshCcw size={16} className="mr-1" />
          Refresh Data
        </Button>
      </div>
      
      <WorkOrderTable workOrders={workOrders || []} isLoading={isLoading} />
    </div>
  );
}
