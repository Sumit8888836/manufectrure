import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { RefreshCcw, ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { WorkOrder, ProductionLine } from "@shared/schema";
import { useState } from "react";
import { formatDateShort } from "@/lib/utils/date-utils";
import { Badge } from "@/components/ui/badge";

export default function Scheduling() {
  const [currentView, setCurrentView] = useState<"day" | "week" | "month">("week");
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Fetch work orders
  const { data: workOrders, isLoading: isLoadingWorkOrders } = useQuery<WorkOrder[]>({
    queryKey: ['/api/work-orders'],
  });
  
  // Fetch production lines
  const { data: productionLines, isLoading: isLoadingLines } = useQuery<ProductionLine[]>({
    queryKey: ['/api/production-lines'],
  });
  
  // Helper to get dates for the current view
  const getDatesForView = () => {
    const dates = [];
    const firstDay = new Date(currentDate);
    
    if (currentView === "day") {
      return [new Date(currentDate)];
    }
    
    if (currentView === "week") {
      // Set to the beginning of the week (Sunday)
      const day = currentDate.getDay();
      firstDay.setDate(currentDate.getDate() - day);
      
      // Get 7 days
      for (let i = 0; i < 7; i++) {
        const date = new Date(firstDay);
        date.setDate(firstDay.getDate() + i);
        dates.push(date);
      }
    }
    
    if (currentView === "month") {
      // Set to the first day of the month
      firstDay.setDate(1);
      
      // Get all days in the month
      const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
      const daysInMonth = lastDay.getDate();
      
      for (let i = 0; i < daysInMonth; i++) {
        const date = new Date(firstDay);
        date.setDate(firstDay.getDate() + i);
        dates.push(date);
      }
    }
    
    return dates;
  };
  
  const dates = getDatesForView();
  
  // Navigate to previous period
  const goToPrevious = () => {
    const newDate = new Date(currentDate);
    if (currentView === "day") {
      newDate.setDate(currentDate.getDate() - 1);
    } else if (currentView === "week") {
      newDate.setDate(currentDate.getDate() - 7);
    } else {
      newDate.setMonth(currentDate.getMonth() - 1);
    }
    setCurrentDate(newDate);
  };
  
  // Navigate to next period
  const goToNext = () => {
    const newDate = new Date(currentDate);
    if (currentView === "day") {
      newDate.setDate(currentDate.getDate() + 1);
    } else if (currentView === "week") {
      newDate.setDate(currentDate.getDate() + 7);
    } else {
      newDate.setMonth(currentDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };
  
  // Format the header based on the current view
  const getHeaderText = () => {
    if (currentView === "day") {
      return formatDateShort(currentDate);
    } else if (currentView === "week") {
      const startDate = formatDateShort(dates[0]);
      const endDate = formatDateShort(dates[dates.length - 1]);
      return `${startDate} - ${endDate}`;
    } else {
      return currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
    }
  };

  // Helper to determine if a work order is scheduled on a specific date
  const isWorkOrderScheduledOn = (workOrder: WorkOrder, date: Date) => {
    if (!workOrder.startDate || !workOrder.dueDate) return false;
    
    const startDate = new Date(workOrder.startDate);
    const dueDate = new Date(workOrder.dueDate);
    
    // Remove time component for comparison
    startDate.setHours(0, 0, 0, 0);
    dueDate.setHours(0, 0, 0, 0);
    const comparableDate = new Date(date);
    comparableDate.setHours(0, 0, 0, 0);
    
    return comparableDate >= startDate && comparableDate <= dueDate;
  };
  
  // Helper function to get status badge class
  const getStatusBadgeClass = (status: string) => {
    return status === "in-progress" ? "bg-green-100 text-green-800" :
           status === "pending" ? "bg-yellow-100 text-yellow-800" :
           status === "scheduled" ? "bg-blue-100 text-blue-800" :
           status === "completed" ? "bg-gray-100 text-gray-800" :
           "bg-red-100 text-red-800";
  };
  
  // Helper function to format status
  const formatStatus = (status: string) => {
    return status.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Production Scheduling</h1>
          <p className="text-gray-500">Plan and manage production schedules</p>
        </div>
        <div className="flex gap-2">
          <Button>
            Assign Work Orders
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle>Schedule View</CardTitle>
          <div className="flex items-center gap-4">
            <Select value={currentView} onValueChange={(value) => setCurrentView(value as any)}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Select view" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Day</SelectItem>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="month">Month</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex items-center">
              <Button variant="ghost" size="icon" onClick={goToPrevious}>
                <ChevronLeft size={16} />
              </Button>
              <span className="mx-2 font-medium">{getHeaderText()}</span>
              <Button variant="ghost" size="icon" onClick={goToNext}>
                <ChevronRight size={16} />
              </Button>
            </div>
            
            <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
              Today
            </Button>
            
            <Button variant="outline" size="sm">
              <RefreshCcw size={16} className="mr-1" />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingLines || isLoadingWorkOrders ? (
            <div className="h-96 flex items-center justify-center">
              <p className="text-gray-500">Loading schedule data...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="bg-blue-50 text-blue-600 font-medium w-48">Production Line</TableHead>
                    {dates.map((date, index) => (
                      <TableHead key={index} className="bg-blue-50 text-blue-600 font-medium min-w-44">
                        {formatDateShort(date)}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productionLines?.map((line) => (
                    <TableRow key={line.id} className="hover:bg-gray-50">
                      <TableCell className="font-medium">{line.name}</TableCell>
                      {dates.map((date, index) => {
                        // Find work orders for this production line on this date
                        const ordersForDay = workOrders?.filter(order => 
                          order.assignedLineId === line.id && isWorkOrderScheduledOn(order, date)
                        ) || [];
                        
                        return (
                          <TableCell key={index} className="p-1 align-top">
                            {ordersForDay.length > 0 ? (
                              <div className="space-y-2">
                                {ordersForDay.map(order => (
                                  <div key={order.id} className="p-2 bg-blue-50 rounded text-sm">
                                    <div className="font-medium">{order.orderId}</div>
                                    <div className="text-xs text-gray-500 truncate" title={order.product}>
                                      {order.product}
                                    </div>
                                    <div className="mt-1 flex justify-between items-center">
                                      <Badge className={getStatusBadgeClass(order.status)} variant="outline">
                                        {formatStatus(order.status)}
                                      </Badge>
                                      <span className="text-xs">{order.progress}%</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div className="h-12 flex items-center justify-center text-gray-400">
                                <span className="text-xs">No orders</span>
                              </div>
                            )}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
