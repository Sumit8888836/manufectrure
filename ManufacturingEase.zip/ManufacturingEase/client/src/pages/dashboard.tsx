import { useQuery } from "@tanstack/react-query";
import KPICard from "@/components/dashboard/KPICard";
import ProductionLineTable from "@/components/dashboard/ProductionLineTable";
import EquipmentCard from "@/components/dashboard/EquipmentCard";
import WorkOrderTable from "@/components/dashboard/WorkOrderTable";
import ProductionChart from "@/components/dashboard/ProductionChart";
import UtilizationChart from "@/components/dashboard/UtilizationChart";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FilterIcon, RefreshCcw } from "lucide-react";

// Sample chart data for production trends
const productionData = [
  { name: 'Mon', lineA: 420, lineB: 320, lineD: 280 },
  { name: 'Tue', lineA: 430, lineB: 340, lineD: 290 },
  { name: 'Wed', lineA: 448, lineB: 360, lineD: 310 },
  { name: 'Thu', lineA: 470, lineB: 350, lineD: 330 },
  { name: 'Fri', lineA: 460, lineB: 370, lineD: 340 },
  { name: 'Sat', lineA: 450, lineB: 390, lineD: 360 },
  { name: 'Sun', lineA: 478, lineB: 410, lineD: 380 },
];

// Sample data for utilization chart
const utilizationData = [
  { name: 'Running', value: 68, color: '#388E3C' },
  { name: 'Idle', value: 17, color: '#F57C00' },
  { name: 'Maintenance', value: 10, color: '#7B1FA2' },
  { name: 'Stopped', value: 5, color: '#D32F2F' },
];

export default function Dashboard() {
  // Fetch latest production metrics
  const { data: productionMetrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ['/api/production-metrics/latest'],
  });
  
  // Fetch production lines
  const { data: productionLines, isLoading: isLoadingLines } = useQuery({
    queryKey: ['/api/production-lines'],
  });
  
  // Fetch equipment
  const { data: equipment, isLoading: isLoadingEquipment } = useQuery({
    queryKey: ['/api/equipment'],
  });
  
  // Fetch work orders
  const { data: workOrders, isLoading: isLoadingWorkOrders } = useQuery({
    queryKey: ['/api/work-orders'],
  });
  
  // Helper function to find the latest metric for a specific line
  const getMetricForLine = (lineId: number) => {
    if (!productionMetrics) return null;
    return productionMetrics.find((metric: any) => metric.lineId === lineId);
  };
  
  // Calculate average OEE across all lines
  const calculateAverageOEE = () => {
    if (!productionMetrics || productionMetrics.length === 0) return 0;
    const sum = productionMetrics.reduce((acc: number, metric: any) => acc + (metric.oee || 0), 0);
    return (sum / productionMetrics.length).toFixed(1);
  };
  
  // Calculate average production rate
  const calculateAverageProductionRate = () => {
    if (!productionMetrics || productionMetrics.length === 0) return 0;
    const sum = productionMetrics.reduce((acc: number, metric: any) => acc + (metric.productionRate || 0), 0);
    return Math.round(sum / productionMetrics.length);
  };
  
  // Calculate average quality rate
  const calculateAverageQualityRate = () => {
    if (!productionMetrics || productionMetrics.length === 0) return 0;
    const sum = productionMetrics.reduce((acc: number, metric: any) => acc + (metric.qualityRate || 0), 0);
    return (sum / productionMetrics.length).toFixed(1);
  };
  
  // Calculate total downtime
  const calculateTotalDowntime = () => {
    if (!productionMetrics || productionMetrics.length === 0) return 0;
    return productionMetrics.reduce((acc: number, metric: any) => acc + (metric.downtime || 0), 0);
  };

  return (
    <div>
      {/* KPI Summary Section */}
      <section className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            title="OEE (Overall Equipment Effectiveness)"
            value={`${calculateAverageOEE()}%`}
            trend="up"
            trendValue="↑ 2.1%"
            progressValue={parseFloat(calculateAverageOEE())}
            progressColor="primary"
            icon="trending_up"
          />
          
          <KPICard
            title="Production Rate"
            value={calculateAverageProductionRate()}
            trend="flat"
            progressValue={82}
            progressColor="warning"
            icon="trending_flat"
            suffix="units/hour"
          />
          
          <KPICard
            title="Quality Rate"
            value={`${calculateAverageQualityRate()}%`}
            trend="up"
            trendValue="↑ 0.8%"
            progressValue={parseFloat(calculateAverageQualityRate())}
            progressColor="secondary"
            icon="trending_up"
          />
          
          <KPICard
            title="Downtime"
            value={calculateTotalDowntime()}
            trend="down"
            trendValue="↓ 15%"
            progressValue={17.5}
            progressColor="error"
            icon="trending_down"
            suffix="minutes"
          />
        </div>
      </section>
      
      {/* Production Line Overview Section */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-medium text-gray-800">Production Line Status</h2>
          <div className="flex">
            <Button variant="outline" size="sm" className="mr-2">
              <FilterIcon size={16} className="mr-1" />
              Filter
            </Button>
            <Button size="sm">
              <RefreshCcw size={16} className="mr-1" />
              Refresh
            </Button>
          </div>
        </div>
        
        <ProductionLineTable 
          productionLines={productionLines || []} 
          isLoading={isLoadingLines} 
        />
      </section>
      
      {/* Charts & Analytics Section */}
      <section className="mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ProductionChart data={productionData} />
          <UtilizationChart data={utilizationData} />
        </div>
      </section>
      
      {/* Equipment Status Section */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-medium text-gray-800">Equipment Status</h2>
          <Link href="/equipment">
            <Button variant="link" className="text-blue-600 hover:text-blue-800">View All</Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoadingEquipment ? (
            <>
              <div className="h-48 bg-gray-100 rounded-lg animate-pulse"></div>
              <div className="h-48 bg-gray-100 rounded-lg animate-pulse"></div>
              <div className="h-48 bg-gray-100 rounded-lg animate-pulse"></div>
            </>
          ) : (
            equipment?.slice(0, 3).map((item: any) => (
              <EquipmentCard key={item.id} equipment={item} />
            ))
          )}
        </div>
      </section>
      
      {/* Recent Work Orders Section */}
      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-medium text-gray-800">Recent Work Orders</h2>
          <Link href="/work-orders">
            <Button variant="link" className="text-blue-600 hover:text-blue-800">View All</Button>
          </Link>
        </div>
        
        <WorkOrderTable 
          workOrders={workOrders || []} 
          isLoading={isLoadingWorkOrders} 
        />
      </section>
    </div>
  );
}
