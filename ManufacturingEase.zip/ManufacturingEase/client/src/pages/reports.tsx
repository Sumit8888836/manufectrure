import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { FilterIcon, RefreshCcw, Download, Printer } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { format, subDays } from "date-fns";
import { useState } from "react";
import { ProductionMetric, WorkOrder, InventoryItem, Equipment } from "@shared/schema";

// Sample data for demo visualization
const generateDateRange = (days: number) => {
  return Array.from({ length: days }).map((_, i) => {
    const date = subDays(new Date(), days - i - 1);
    return format(date, 'MMM dd');
  });
};

// Helper function to generate production data for visualization
const generateProductionData = (metrics: ProductionMetric[] | undefined, dateRange: string[]) => {
  if (!metrics || metrics.length === 0) return [];
  
  // Group metrics by lineId
  const lineMetrics: Record<number, ProductionMetric[]> = {};
  metrics.forEach(metric => {
    if (!lineMetrics[metric.lineId]) {
      lineMetrics[metric.lineId] = [];
    }
    lineMetrics[metric.lineId].push(metric);
  });
  
  // Generate data for each day in the range
  return dateRange.map((date, index) => {
    const dataPoint: any = { name: date };
    
    // Add data for each production line
    Object.keys(lineMetrics).forEach(lineId => {
      const lineIdNum = parseInt(lineId);
      // simulate some data based on index
      dataPoint[`line${lineIdNum}`] = 
        Math.floor(Math.random() * 100) + 350 + (index * 5);
    });
    
    return dataPoint;
  });
};

export default function Reports() {
  const [reportTimeframe, setReportTimeframe] = useState("30days");
  const [reportType, setReportType] = useState("production");
  
  // Fetch production metrics
  const { data: productionMetrics, isLoading: isLoadingMetrics } = useQuery<ProductionMetric[]>({
    queryKey: ['/api/production-metrics'],
  });
  
  // Fetch work orders
  const { data: workOrders, isLoading: isLoadingWorkOrders } = useQuery<WorkOrder[]>({
    queryKey: ['/api/work-orders'],
  });
  
  // Fetch inventory
  const { data: inventory, isLoading: isLoadingInventory } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory'],
  });
  
  // Fetch equipment
  const { data: equipment, isLoading: isLoadingEquipment } = useQuery<Equipment[]>({
    queryKey: ['/api/equipment'],
  });
  
  // Determine date range based on selected timeframe
  const getDaysForTimeframe = () => {
    switch (reportTimeframe) {
      case "7days": return 7;
      case "14days": return 14;
      case "30days": return 30;
      case "90days": return 90;
      default: return 30;
    }
  };
  
  const dateRange = generateDateRange(getDaysForTimeframe());
  const productionData = generateProductionData(productionMetrics, dateRange);
  
  // Quality data for pie chart
  const qualityData = [
    { name: "Passed", value: 96, color: "#4CAF50" },
    { name: "Minor Defects", value: 3, color: "#FFC107" },
    { name: "Major Defects", value: 1, color: "#F44336" }
  ];
  
  // Downtime categories for bar chart
  const downtimeData = [
    { name: "Equipment Failure", hours: 8.2 },
    { name: "Setup Time", hours: 5.3 },
    { name: "Material Shortage", hours: 3.1 },
    { name: "Scheduled Maintenance", hours: 4.7 },
    { name: "Operator Unavailable", hours: 1.2 }
  ];
  
  // Work order status for pie chart
  const calculateWorkOrderStatusData = () => {
    if (!workOrders || workOrders.length === 0) return [];
    
    const statusCount: Record<string, number> = {
      "scheduled": 0,
      "in-progress": 0,
      "pending": 0,
      "completed": 0,
      "delayed": 0
    };
    
    workOrders.forEach(order => {
      if (statusCount[order.status] !== undefined) {
        statusCount[order.status]++;
      }
    });
    
    return [
      { name: "Scheduled", value: statusCount["scheduled"], color: "#2196F3" },
      { name: "In Progress", value: statusCount["in-progress"], color: "#4CAF50" },
      { name: "Pending", value: statusCount["pending"], color: "#FFC107" },
      { name: "Completed", value: statusCount["completed"], color: "#9E9E9E" },
      { name: "Delayed", value: statusCount["delayed"], color: "#F44336" }
    ];
  };
  
  const workOrderStatusData = calculateWorkOrderStatusData();
  
  // Inventory categories for pie chart
  const calculateInventoryData = () => {
    if (!inventory || inventory.length === 0) return [];
    
    const categoryCount: Record<string, number> = {};
    
    inventory.forEach(item => {
      if (!categoryCount[item.category]) {
        categoryCount[item.category] = 0;
      }
      categoryCount[item.category] += item.quantity;
    });
    
    const colors = ["#2196F3", "#4CAF50", "#FFC107", "#9C27B0", "#FF5722", "#607D8B"];
    
    return Object.keys(categoryCount).map((category, index) => ({
      name: category,
      value: categoryCount[category],
      color: colors[index % colors.length]
    }));
  };
  
  const inventoryData = calculateInventoryData();
  
  // Equipment status for pie chart
  const calculateEquipmentStatusData = () => {
    if (!equipment || equipment.length === 0) return [];
    
    const statusCount: Record<string, number> = {
      "running": 0,
      "idle": 0,
      "maintenance": 0,
      "stopped": 0
    };
    
    equipment.forEach(item => {
      if (statusCount[item.status] !== undefined) {
        statusCount[item.status]++;
      }
    });
    
    return [
      { name: "Running", value: statusCount["running"], color: "#4CAF50" },
      { name: "Idle", value: statusCount["idle"], color: "#FFC107" },
      { name: "Maintenance", value: statusCount["maintenance"], color: "#9C27B0" },
      { name: "Stopped", value: statusCount["stopped"], color: "#F44336" }
    ];
  };
  
  const equipmentStatusData = calculateEquipmentStatusData();
  
  // Loading state
  const isLoading = isLoadingMetrics || isLoadingWorkOrders || isLoadingInventory || isLoadingEquipment;
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Production Reports</h1>
          <p className="text-gray-500">Analyze manufacturing performance metrics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Printer size={16} className="mr-2" />
            Print Report
          </Button>
          <Button variant="outline">
            <Download size={16} className="mr-2" />
            Export Data
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Report Settings</CardTitle>
              <CardDescription>
                Configure the report parameters
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <RefreshCcw size={16} className="mr-1" />
              Refresh Data
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="w-full sm:w-auto">
              <label className="block text-sm font-medium text-gray-700 mb-1">Report Type</label>
              <Tabs 
                value={reportType} 
                onValueChange={setReportType} 
                className="w-full sm:w-auto"
              >
                <TabsList className="grid grid-cols-4 w-full max-w-md">
                  <TabsTrigger value="production">Production</TabsTrigger>
                  <TabsTrigger value="quality">Quality</TabsTrigger>
                  <TabsTrigger value="equipment">Equipment</TabsTrigger>
                  <TabsTrigger value="inventory">Inventory</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            <div className="w-full sm:w-auto">
              <label className="block text-sm font-medium text-gray-700 mb-1">Time Period</label>
              <Select value={reportTimeframe} onValueChange={setReportTimeframe}>
                <SelectTrigger className="w-full sm:w-[200px]">
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 Days</SelectItem>
                  <SelectItem value="14days">Last 14 Days</SelectItem>
                  <SelectItem value="30days">Last 30 Days</SelectItem>
                  <SelectItem value="90days">Last 90 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full sm:w-auto">
              <label className="block text-sm font-medium text-gray-700 mb-1">Filter Options</label>
              <Button variant="outline" className="w-full sm:w-auto">
                <FilterIcon size={16} className="mr-2" />
                Additional Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Summary Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-sm text-blue-600 mb-1">Average OEE</div>
                <div className="text-2xl font-bold">78.3%</div>
                <div className="text-xs text-blue-700 mt-1">↑ 2.1% from previous period</div>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="text-sm text-green-600 mb-1">Quality Rate</div>
                <div className="text-2xl font-bold">96.7%</div>
                <div className="text-xs text-green-700 mt-1">↑ 0.8% from previous period</div>
              </div>
              
              <div className="p-4 bg-orange-50 rounded-lg">
                <div className="text-sm text-orange-600 mb-1">Avg. Production Rate</div>
                <div className="text-2xl font-bold">412 units/hr</div>
                <div className="text-xs text-orange-700 mt-1">→ No change from previous period</div>
              </div>
              
              <div className="p-4 bg-red-50 rounded-lg">
                <div className="text-sm text-red-600 mb-1">Total Downtime</div>
                <div className="text-2xl font-bold">22.5 hours</div>
                <div className="text-xs text-green-700 mt-1">↓ 15% from previous period</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {reportType === "production" && (
          <Card>
            <CardHeader>
              <CardTitle>Production Trends by Line</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                {isLoading ? (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-gray-500">Loading production data...</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={productionData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="line1" name="Line A" stroke="#1976D2" strokeWidth={2} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="line2" name="Line B" stroke="#388E3C" strokeWidth={2} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="line4" name="Line D" stroke="#F57C00" strokeWidth={2} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {reportType === "quality" && (
          <Card>
            <CardHeader>
              <CardTitle>Quality Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={qualityData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {qualityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value) => [`${value}%`, 'Percentage']}
                    />
                    <Legend layout="vertical" align="right" verticalAlign="middle" />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
        
        {reportType === "equipment" && (
          <Card>
            <CardHeader>
              <CardTitle>Equipment Status Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                {isLoadingEquipment ? (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-gray-500">Loading equipment data...</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={equipmentStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={3}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {equipmentStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend layout="vertical" align="right" verticalAlign="middle" />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {reportType === "inventory" && (
          <Card>
            <CardHeader>
              <CardTitle>Inventory Distribution by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                {isLoadingInventory ? (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-gray-500">Loading inventory data...</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={inventoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={3}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {inventoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend layout="vertical" align="right" verticalAlign="middle" />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {reportType === "production" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Work Order Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {isLoadingWorkOrders ? (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-gray-500">Loading work order data...</p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={workOrderStatusData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={3}
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {workOrderStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend layout="vertical" align="right" verticalAlign="middle" />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Production Efficiency by Line</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { name: "Line A", efficiency: 84 },
                        { name: "Line B", efficiency: 72 },
                        { name: "Line C", efficiency: 0 },
                        { name: "Line D", efficiency: 91 }
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="efficiency" name="Efficiency %" fill="#1976D2" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </>
        )}
        
        {reportType === "quality" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Defect Types Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { name: "Surface Defects", count: 45 },
                        { name: "Dimension Errors", count: 32 },
                        { name: "Assembly Issues", count: 28 },
                        { name: "Material Flaws", count: 18 },
                        { name: "Electrical Faults", count: 12 }
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" name="Defect Count" fill="#F44336" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Quality Trend Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={dateRange.map((date, index) => ({
                        name: date,
                        qualityRate: 95 + Math.sin(index * 0.5) * 2
                      }))}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="name" />
                      <YAxis domain={[90, 100]} />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="qualityRate" 
                        name="Quality Rate %" 
                        stroke="#4CAF50" 
                        strokeWidth={2} 
                        dot={{ r: 4 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </>
        )}
        
        {reportType === "equipment" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Downtime by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={downtimeData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="hours" name="Hours" fill="#F44336" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Equipment Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { name: "CNC Machine #103", utilization: 87 },
                        { name: "Robotic Arm #57", utilization: 0 },
                        { name: "Conveyor Line #24", utilization: 42 }
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis type="category" dataKey="name" />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="utilization" name="Utilization %" fill="#1976D2" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </>
        )}
        
        {reportType === "inventory" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Inventory Level vs. Reorder Point</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {isLoadingInventory ? (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-gray-500">Loading inventory data...</p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={inventory?.slice(0, 5).map(item => ({
                          name: item.name.length > 15 ? item.name.substring(0, 15) + '...' : item.name,
                          quantity: item.quantity,
                          reorderLevel: item.reorderLevel || 0
                        }))}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="quantity" name="Current Quantity" fill="#2196F3" />
                        <Bar dataKey="reorderLevel" name="Reorder Level" fill="#FF9800" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Inventory Value by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {isLoadingInventory ? (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-gray-500">Loading inventory data...</p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={inventoryData.map(item => ({
                          name: item.name,
                          value: item.value * 3.5 // Rough estimate of value
                        }))}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Value']} />
                        <Legend />
                        <Bar dataKey="value" name="Value ($)" fill="#673AB7" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
