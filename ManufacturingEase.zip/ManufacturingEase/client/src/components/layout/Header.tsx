import { getCurrentFormattedDate } from "@/lib/utils/date-utils";
import { useSidebar } from "@/lib/hooks/use-sidebar";
import { useEffect, useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLocation } from "wouter";

interface HeaderProps {
  title: string;
}

export default function Header({ title }: HeaderProps) {
  const { collapsed } = useSidebar();
  const [date, setDate] = useState(getCurrentFormattedDate());
  const [location] = useLocation();
  
  // Update date every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setDate(getCurrentFormattedDate());
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);

  // Get the page title based on the current route
  const getTitle = () => {
    if (location === "/") return "Dashboard";
    return title || location.slice(1).split("-").map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(" ");
  };

  return (
    <header className={`z-10 bg-white shadow-sm py-4 px-6 flex justify-between items-center transition-all duration-300 ${collapsed ? 'ml-16' : 'ml-64'}`}>
      <div>
        <h1 className="text-xl font-medium text-gray-800">{getTitle()}</h1>
        <p className="text-sm text-gray-500">{date}</p>
      </div>
      <div className="flex items-center">
        <div className="relative mr-4">
          <button className="flex items-center focus:outline-none mr-5">
            <span className="material-icons text-gray-600 mr-1">notifications</span>
            <span className="bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center absolute -top-1 -right-1">3</span>
          </button>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <div className="flex items-center cursor-pointer">
              <Avatar className="h-8 w-8 bg-blue-600 mr-2">
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <span className="text-gray-700 mr-1">John Doe</span>
              <span className="material-icons text-gray-600">arrow_drop_down</span>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
