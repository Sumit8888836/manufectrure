import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface KPICardProps {
  title: string;
  value: string | number;
  trend?: "up" | "down" | "flat";
  trendValue?: string;
  progressValue: number;
  progressColor?: "primary" | "secondary" | "warning" | "error";
  icon?: string;
  suffix?: string;
}

export default function KPICard({ 
  title, 
  value, 
  trend, 
  trendValue, 
  progressValue, 
  progressColor = "primary",
  icon, 
  suffix 
}: KPICardProps) {
  
  // Map trend to icon and color
  const trendIcon = trend === "up" ? "trending_up" : trend === "down" ? "trending_down" : "trending_flat";
  const trendColorClass = trend === "up" ? "text-green-600" : trend === "down" ? "text-red-600" : "text-orange-500";
  
  // Map progress color
  const progressColorClass = 
    progressColor === "primary" ? "bg-blue-600" : 
    progressColor === "secondary" ? "bg-green-600" : 
    progressColor === "warning" ? "bg-orange-500" : 
    "bg-red-600";

  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
          {icon && <span className={`material-icons ${trendColorClass}`}>{icon}</span>}
        </div>
        <div className="flex items-end">
          <p className="text-3xl font-bold text-gray-800">{value}</p>
          {suffix && <span className="ml-2 text-xs text-gray-500">{suffix}</span>}
          {trendValue && <span className={`ml-2 text-xs font-medium ${trendColorClass}`}>{trendValue}</span>}
        </div>
        <div className="mt-2">
          <Progress value={progressValue} className="h-1 bg-gray-200">
            <div className={`h-1 ${progressColorClass} rounded-full`} style={{ width: `${progressValue}%` }}></div>
          </Progress>
        </div>
      </CardContent>
    </Card>
  );
}
