import { Card, CardContent } from "@/components/ui/card";
import { Equipment } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { formatDateShort } from "@/lib/utils/date-utils";

interface EquipmentCardProps {
  equipment: Equipment;
}

export default function EquipmentCard({ equipment }: EquipmentCardProps) {
  // Helper to get status indicator class
  const getStatusClass = (status: string) => {
    return status === "running" ? "bg-green-600" :
           status === "idle" ? "bg-orange-500" :
           status === "maintenance" ? "bg-purple-600" :
           "bg-red-600";
  };
  
  // Helper to format status
  const formatStatus = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };
  
  // Helper to get utilization color
  const getUtilizationColor = (utilization: number | null) => {
    if (utilization === null || utilization === 0) return "bg-red-600";
    if (utilization >= 80) return "bg-green-600";
    if (utilization >= 60) return "bg-green-500";
    if (utilization >= 40) return "bg-yellow-500";
    return "bg-orange-500";
  };
  
  // Helper to get runtime percentage (based on 24 hours)
  const getRuntimePercentage = (runtime: number | null) => {
    if (runtime === null || runtime === 0) return 0;
    return (runtime / 24) * 100;
  };

  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex justify-between">
          <div>
            <div className="flex items-center">
              <span className={`w-3 h-3 rounded-full mr-2 ${getStatusClass(equipment.status)}`}></span>
              <h3 className="font-medium">{equipment.name}</h3>
            </div>
            <p className="text-sm text-gray-500 mt-1">{equipment.type}</p>
          </div>
          <span className="material-icons text-gray-400">settings</span>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-500">Utilization</span>
            <span className="font-medium">{equipment.utilization ? `${equipment.utilization}%` : '0%'}</span>
          </div>
          <Progress value={equipment.utilization || 0} className="h-1 bg-gray-200">
            <div 
              className={`h-1 ${getUtilizationColor(equipment.utilization)} rounded-full`} 
              style={{ width: `${equipment.utilization || 0}%` }}>
            </div>
          </Progress>
        </div>
        
        <div className="mt-3">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-500">Runtime</span>
            <span className="font-medium">{equipment.runtime ? `${equipment.runtime} hours` : '0 hours'}</span>
          </div>
          <Progress value={getRuntimePercentage(equipment.runtime)} className="h-1 bg-gray-200">
            <div 
              className="h-1 bg-blue-600 rounded-full" 
              style={{ width: `${getRuntimePercentage(equipment.runtime)}%` }}>
            </div>
          </Progress>
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-100">
          {equipment.errorMessage ? (
            <div className="flex items-center text-sm text-red-600">
              <span className="material-icons text-sm mr-1">warning</span>
              <span>{equipment.errorMessage}</span>
            </div>
          ) : (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Next Maintenance</span>
              <span className="font-medium text-gray-800">
                {equipment.nextMaintenance ? formatDateShort(equipment.nextMaintenance) : 'Not scheduled'}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
