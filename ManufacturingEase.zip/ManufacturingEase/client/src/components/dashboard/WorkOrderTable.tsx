import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { formatDateShort } from "@/lib/utils/date-utils";
import { WorkOrder } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { Eye } from "lucide-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";

interface WorkOrderTableProps {
  workOrders: WorkOrder[];
  isLoading?: boolean;
}

export default function WorkOrderTable({ workOrders, isLoading = false }: WorkOrderTableProps) {
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg overflow-hidden shadow animate-pulse">
        <div className="h-10 bg-gray-200 m-4"></div>
        <div className="h-96 bg-gray-100 m-4"></div>
      </div>
    );
  }
  
  // Helper to get status badge class
  const getStatusBadgeClass = (status: string) => {
    return status === "in-progress" ? "bg-green-100 text-green-800" :
           status === "pending" ? "bg-yellow-100 text-yellow-800" :
           status === "scheduled" ? "bg-blue-100 text-blue-800" :
           status === "completed" ? "bg-gray-100 text-gray-800" :
           "bg-red-100 text-red-800";
  };
  
  // Helper to format status
  const formatStatus = (status: string) => {
    return status.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  };
  
  // Helper to get progress color
  const getProgressColor = (progress: number) => {
    if (progress >= 80) return "bg-green-600";
    if (progress >= 50) return "bg-blue-600";
    if (progress >= 25) return "bg-orange-500";
    if (progress > 0) return "bg-yellow-500";
    return "bg-gray-400";
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Order ID</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Product</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Quantity</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Status</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Start Date</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Due Date</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Progress</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {workOrders.map((order) => (
              <TableRow key={order.id} className="hover:bg-gray-50">
                <TableCell className="font-medium">{order.orderId}</TableCell>
                <TableCell>{order.product}</TableCell>
                <TableCell>{order.quantity.toLocaleString()} units</TableCell>
                <TableCell>
                  <Badge className={getStatusBadgeClass(order.status)} variant="outline">
                    {formatStatus(order.status)}
                  </Badge>
                </TableCell>
                <TableCell>{order.startDate ? formatDateShort(order.startDate) : '--'}</TableCell>
                <TableCell>{order.dueDate ? formatDateShort(order.dueDate) : '--'}</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <span className="mr-2 text-sm">{order.progress}%</span>
                    <div className="w-16">
                      <Progress value={order.progress || 0} className="h-1 bg-gray-200">
                        <div 
                          className={`h-1 ${getProgressColor(order.progress || 0)} rounded-full`} 
                          style={{ width: `${order.progress || 0}%` }}>
                        </div>
                      </Progress>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Link href={`/work-orders/${order.id}`}>
                    <Button variant="ghost" size="icon" className="text-blue-600 hover:text-blue-800">
                      <Eye size={18} />
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
