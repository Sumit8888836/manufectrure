import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertProductionLineSchema, 
  insertEquipmentSchema,
  insertInventoryItemSchema,
  insertWorkOrderSchema,
  insertProductionMetricsSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't return the password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Production Line routes
  app.get("/api/production-lines", async (_req, res) => {
    const productionLines = await storage.getProductionLines();
    res.json(productionLines);
  });
  
  app.get("/api/production-lines/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const productionLine = await storage.getProductionLine(id);
    if (!productionLine) {
      return res.status(404).json({ message: "Production line not found" });
    }
    
    res.json(productionLine);
  });
  
  app.post("/api/production-lines", async (req, res) => {
    try {
      const validatedData = insertProductionLineSchema.parse(req.body);
      const productionLine = await storage.createProductionLine(validatedData);
      res.status(201).json(productionLine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create production line" });
    }
  });
  
  app.patch("/api/production-lines/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      // Partial validation of fields
      const validatedData = insertProductionLineSchema.partial().parse(req.body);
      const updatedProductionLine = await storage.updateProductionLine(id, validatedData);
      
      if (!updatedProductionLine) {
        return res.status(404).json({ message: "Production line not found" });
      }
      
      res.json(updatedProductionLine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update production line" });
    }
  });
  
  // Equipment routes
  app.get("/api/equipment", async (_req, res) => {
    const equipment = await storage.getEquipment();
    res.json(equipment);
  });
  
  app.get("/api/equipment/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const equipmentItem = await storage.getEquipmentById(id);
    if (!equipmentItem) {
      return res.status(404).json({ message: "Equipment not found" });
    }
    
    res.json(equipmentItem);
  });
  
  app.get("/api/production-lines/:id/equipment", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const equipment = await storage.getEquipmentByProductionLine(id);
    res.json(equipment);
  });
  
  app.post("/api/equipment", async (req, res) => {
    try {
      const validatedData = insertEquipmentSchema.parse(req.body);
      const equipment = await storage.createEquipment(validatedData);
      res.status(201).json(equipment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create equipment" });
    }
  });
  
  app.patch("/api/equipment/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const validatedData = insertEquipmentSchema.partial().parse(req.body);
      const updatedEquipment = await storage.updateEquipment(id, validatedData);
      
      if (!updatedEquipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      
      res.json(updatedEquipment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update equipment" });
    }
  });
  
  // Inventory routes
  app.get("/api/inventory", async (_req, res) => {
    const inventoryItems = await storage.getInventoryItems();
    res.json(inventoryItems);
  });
  
  app.get("/api/inventory/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const item = await storage.getInventoryItem(id);
    if (!item) {
      return res.status(404).json({ message: "Inventory item not found" });
    }
    
    res.json(item);
  });
  
  app.post("/api/inventory", async (req, res) => {
    try {
      const validatedData = insertInventoryItemSchema.parse(req.body);
      const item = await storage.createInventoryItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create inventory item" });
    }
  });
  
  app.patch("/api/inventory/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const validatedData = insertInventoryItemSchema.partial().parse(req.body);
      const updatedItem = await storage.updateInventoryItem(id, validatedData);
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update inventory item" });
    }
  });
  
  // Work Order routes
  app.get("/api/work-orders", async (_req, res) => {
    const workOrders = await storage.getWorkOrders();
    res.json(workOrders);
  });
  
  app.get("/api/work-orders/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const workOrder = await storage.getWorkOrder(id);
    if (!workOrder) {
      return res.status(404).json({ message: "Work order not found" });
    }
    
    res.json(workOrder);
  });
  
  app.post("/api/work-orders", async (req, res) => {
    try {
      const validatedData = insertWorkOrderSchema.parse(req.body);
      const workOrder = await storage.createWorkOrder(validatedData);
      res.status(201).json(workOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create work order" });
    }
  });
  
  app.patch("/api/work-orders/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    try {
      const validatedData = insertWorkOrderSchema.partial().parse(req.body);
      const updatedWorkOrder = await storage.updateWorkOrder(id, validatedData);
      
      if (!updatedWorkOrder) {
        return res.status(404).json({ message: "Work order not found" });
      }
      
      res.json(updatedWorkOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update work order" });
    }
  });
  
  // Production Metrics routes
  app.get("/api/production-metrics", async (_req, res) => {
    const metrics = await storage.getProductionMetrics();
    res.json(metrics);
  });
  
  app.get("/api/production-metrics/latest", async (_req, res) => {
    const metrics = await storage.getLatestProductionMetrics();
    res.json(metrics);
  });
  
  app.get("/api/production-lines/:id/metrics", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const metrics = await storage.getProductionMetricsForLine(id);
    res.json(metrics);
  });
  
  app.post("/api/production-metrics", async (req, res) => {
    try {
      const validatedData = insertProductionMetricsSchema.parse(req.body);
      const metric = await storage.createProductionMetric(validatedData);
      res.status(201).json(metric);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create production metric" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
