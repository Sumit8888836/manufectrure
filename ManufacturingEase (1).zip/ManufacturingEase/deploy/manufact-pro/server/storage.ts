import {
  users, type User, type InsertUser,
  productionLines, type ProductionLine, type InsertProductionLine,
  equipment, type Equipment, type InsertEquipment,
  inventoryItems, type InventoryItem, type InsertInventoryItem,
  workOrders, type WorkOrder, type InsertWorkOrder,
  productionMetrics, type ProductionMetric, type InsertProductionMetric,
  customers, type Customer, type InsertCustomer,
  salesOrders, type SalesOrder, type InsertSalesOrder,
  salesOrderItems, type SalesOrderItem, type InsertSalesOrderItem,
  products, type Product, type InsertProduct
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Production Line methods
  getProductionLines(): Promise<ProductionLine[]>;
  getProductionLine(id: number): Promise<ProductionLine | undefined>;
  createProductionLine(productionLine: InsertProductionLine): Promise<ProductionLine>;
  updateProductionLine(id: number, productionLine: Partial<InsertProductionLine>): Promise<ProductionLine | undefined>;
  
  // Equipment methods
  getEquipment(): Promise<Equipment[]>;
  getEquipmentById(id: number): Promise<Equipment | undefined>;
  getEquipmentByProductionLine(productionLineId: number): Promise<Equipment[]>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: number, equipmentData: Partial<InsertEquipment>): Promise<Equipment | undefined>;
  
  // Inventory methods
  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  
  // Work Order methods
  getWorkOrders(): Promise<WorkOrder[]>;
  getWorkOrder(id: number): Promise<WorkOrder | undefined>;
  createWorkOrder(workOrder: InsertWorkOrder): Promise<WorkOrder>;
  updateWorkOrder(id: number, workOrder: Partial<InsertWorkOrder>): Promise<WorkOrder | undefined>;
  
  // Production Metrics methods
  getProductionMetrics(): Promise<ProductionMetric[]>;
  getProductionMetricsForLine(lineId: number): Promise<ProductionMetric[]>;
  createProductionMetric(metric: InsertProductionMetric): Promise<ProductionMetric>;
  getLatestProductionMetrics(): Promise<ProductionMetric[]>;
  
  // Customer methods
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  
  // Product methods
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  
  // Sales Order methods
  getSalesOrders(): Promise<SalesOrder[]>;
  getSalesOrder(id: number): Promise<SalesOrder | undefined>;
  getSalesOrdersByCustomer(customerId: number): Promise<SalesOrder[]>;
  createSalesOrder(salesOrder: InsertSalesOrder): Promise<SalesOrder>;
  updateSalesOrder(id: number, salesOrder: Partial<InsertSalesOrder>): Promise<SalesOrder | undefined>;
  
  // Sales Order Item methods
  getSalesOrderItems(salesOrderId: number): Promise<SalesOrderItem[]>;
  getSalesOrderItem(id: number): Promise<SalesOrderItem | undefined>;
  createSalesOrderItem(item: InsertSalesOrderItem): Promise<SalesOrderItem>;
  updateSalesOrderItem(id: number, item: Partial<InsertSalesOrderItem>): Promise<SalesOrderItem | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private productionLinesMap: Map<number, ProductionLine>;
  private equipmentMap: Map<number, Equipment>;
  private inventoryItemsMap: Map<number, InventoryItem>;
  private workOrdersMap: Map<number, WorkOrder>;
  private productionMetricsMap: Map<number, ProductionMetric>;
  private customersMap: Map<number, Customer>;
  private productsMap: Map<number, Product>;
  private salesOrdersMap: Map<number, SalesOrder>;
  private salesOrderItemsMap: Map<number, SalesOrderItem>;
  
  private currentUserId: number;
  private currentProductionLineId: number;
  private currentEquipmentId: number;
  private currentInventoryItemId: number;
  private currentWorkOrderId: number;
  private currentProductionMetricId: number;
  private currentCustomerId: number;
  private currentProductId: number;
  private currentSalesOrderId: number;
  private currentSalesOrderItemId: number;

  constructor() {
    this.users = new Map();
    this.productionLinesMap = new Map();
    this.equipmentMap = new Map();
    this.inventoryItemsMap = new Map();
    this.workOrdersMap = new Map();
    this.productionMetricsMap = new Map();
    this.customersMap = new Map();
    this.productsMap = new Map();
    this.salesOrdersMap = new Map();
    this.salesOrderItemsMap = new Map();
    
    this.currentUserId = 1;
    this.currentProductionLineId = 1;
    this.currentEquipmentId = 1;
    this.currentInventoryItemId = 1;
    this.currentWorkOrderId = 1;
    this.currentProductionMetricId = 1;
    this.currentCustomerId = 1;
    this.currentProductId = 1;
    this.currentSalesOrderId = 1;
    this.currentSalesOrderItemId = 1;
    
    this.initializeWithSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Production Line methods
  async getProductionLines(): Promise<ProductionLine[]> {
    return Array.from(this.productionLinesMap.values());
  }
  
  async getProductionLine(id: number): Promise<ProductionLine | undefined> {
    return this.productionLinesMap.get(id);
  }
  
  async createProductionLine(productionLine: InsertProductionLine): Promise<ProductionLine> {
    const id = this.currentProductionLineId++;
    const newProductionLine: ProductionLine = { ...productionLine, id };
    this.productionLinesMap.set(id, newProductionLine);
    return newProductionLine;
  }
  
  async updateProductionLine(id: number, productionLineData: Partial<InsertProductionLine>): Promise<ProductionLine | undefined> {
    const existingProductionLine = this.productionLinesMap.get(id);
    if (!existingProductionLine) return undefined;
    
    const updatedProductionLine = { ...existingProductionLine, ...productionLineData };
    this.productionLinesMap.set(id, updatedProductionLine);
    return updatedProductionLine;
  }
  
  // Equipment methods
  async getEquipment(): Promise<Equipment[]> {
    return Array.from(this.equipmentMap.values());
  }
  
  async getEquipmentById(id: number): Promise<Equipment | undefined> {
    return this.equipmentMap.get(id);
  }
  
  async getEquipmentByProductionLine(productionLineId: number): Promise<Equipment[]> {
    return Array.from(this.equipmentMap.values()).filter(
      equipment => equipment.productionLineId === productionLineId
    );
  }
  
  async createEquipment(equipmentData: InsertEquipment): Promise<Equipment> {
    const id = this.currentEquipmentId++;
    const newEquipment: Equipment = { ...equipmentData, id };
    this.equipmentMap.set(id, newEquipment);
    return newEquipment;
  }
  
  async updateEquipment(id: number, equipmentData: Partial<InsertEquipment>): Promise<Equipment | undefined> {
    const existingEquipment = this.equipmentMap.get(id);
    if (!existingEquipment) return undefined;
    
    const updatedEquipment = { ...existingEquipment, ...equipmentData };
    this.equipmentMap.set(id, updatedEquipment);
    return updatedEquipment;
  }
  
  // Inventory methods
  async getInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItemsMap.values());
  }
  
  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    return this.inventoryItemsMap.get(id);
  }
  
  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.currentInventoryItemId++;
    const newItem: InventoryItem = { ...item, id };
    this.inventoryItemsMap.set(id, newItem);
    return newItem;
  }
  
  async updateInventoryItem(id: number, itemData: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const existingItem = this.inventoryItemsMap.get(id);
    if (!existingItem) return undefined;
    
    const updatedItem = { ...existingItem, ...itemData };
    this.inventoryItemsMap.set(id, updatedItem);
    return updatedItem;
  }
  
  // Work Order methods
  async getWorkOrders(): Promise<WorkOrder[]> {
    return Array.from(this.workOrdersMap.values());
  }
  
  async getWorkOrder(id: number): Promise<WorkOrder | undefined> {
    return this.workOrdersMap.get(id);
  }
  
  async createWorkOrder(workOrder: InsertWorkOrder): Promise<WorkOrder> {
    const id = this.currentWorkOrderId++;
    const newWorkOrder: WorkOrder = { ...workOrder, id };
    this.workOrdersMap.set(id, newWorkOrder);
    return newWorkOrder;
  }
  
  async updateWorkOrder(id: number, workOrderData: Partial<InsertWorkOrder>): Promise<WorkOrder | undefined> {
    const existingWorkOrder = this.workOrdersMap.get(id);
    if (!existingWorkOrder) return undefined;
    
    const updatedWorkOrder = { ...existingWorkOrder, ...workOrderData };
    this.workOrdersMap.set(id, updatedWorkOrder);
    return updatedWorkOrder;
  }
  
  // Production Metrics methods
  async getProductionMetrics(): Promise<ProductionMetric[]> {
    return Array.from(this.productionMetricsMap.values());
  }
  
  async getProductionMetricsForLine(lineId: number): Promise<ProductionMetric[]> {
    return Array.from(this.productionMetricsMap.values()).filter(
      metric => metric.lineId === lineId
    );
  }
  
  async createProductionMetric(metric: InsertProductionMetric): Promise<ProductionMetric> {
    const id = this.currentProductionMetricId++;
    const newMetric: ProductionMetric = { ...metric, id };
    this.productionMetricsMap.set(id, newMetric);
    return newMetric;
  }
  
  async getLatestProductionMetrics(): Promise<ProductionMetric[]> {
    // Group by lineId and get the most recent metric for each line
    const metrics = Array.from(this.productionMetricsMap.values());
    const lineMap = new Map<number, ProductionMetric>();
    
    for (const metric of metrics) {
      const existingMetric = lineMap.get(metric.lineId);
      if (!existingMetric || new Date(metric.date) > new Date(existingMetric.date)) {
        lineMap.set(metric.lineId, metric);
      }
    }
    
    return Array.from(lineMap.values());
  }
  
  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customersMap.values());
  }
  
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customersMap.get(id);
  }
  
  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const newCustomer: Customer = { ...customer, id };
    this.customersMap.set(id, newCustomer);
    return newCustomer;
  }
  
  async updateCustomer(id: number, customerData: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const existingCustomer = this.customersMap.get(id);
    if (!existingCustomer) return undefined;
    
    const updatedCustomer = { ...existingCustomer, ...customerData };
    this.customersMap.set(id, updatedCustomer);
    return updatedCustomer;
  }
  
  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.productsMap.values());
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsMap.get(id);
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const newProduct: Product = { ...product, id };
    this.productsMap.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.productsMap.get(id);
    if (!existingProduct) return undefined;
    
    const updatedProduct = { ...existingProduct, ...productData };
    this.productsMap.set(id, updatedProduct);
    return updatedProduct;
  }
  
  // Sales Order methods
  async getSalesOrders(): Promise<SalesOrder[]> {
    return Array.from(this.salesOrdersMap.values());
  }
  
  async getSalesOrder(id: number): Promise<SalesOrder | undefined> {
    return this.salesOrdersMap.get(id);
  }
  
  async getSalesOrdersByCustomer(customerId: number): Promise<SalesOrder[]> {
    return Array.from(this.salesOrdersMap.values()).filter(
      order => order.customerId === customerId
    );
  }
  
  async createSalesOrder(salesOrder: InsertSalesOrder): Promise<SalesOrder> {
    const id = this.currentSalesOrderId++;
    const newSalesOrder: SalesOrder = { ...salesOrder, id };
    this.salesOrdersMap.set(id, newSalesOrder);
    return newSalesOrder;
  }
  
  async updateSalesOrder(id: number, salesOrderData: Partial<InsertSalesOrder>): Promise<SalesOrder | undefined> {
    const existingSalesOrder = this.salesOrdersMap.get(id);
    if (!existingSalesOrder) return undefined;
    
    const updatedSalesOrder = { ...existingSalesOrder, ...salesOrderData };
    this.salesOrdersMap.set(id, updatedSalesOrder);
    return updatedSalesOrder;
  }
  
  // Sales Order Item methods
  async getSalesOrderItems(salesOrderId: number): Promise<SalesOrderItem[]> {
    return Array.from(this.salesOrderItemsMap.values()).filter(
      item => item.salesOrderId === salesOrderId
    );
  }
  
  async getSalesOrderItem(id: number): Promise<SalesOrderItem | undefined> {
    return this.salesOrderItemsMap.get(id);
  }
  
  async createSalesOrderItem(item: InsertSalesOrderItem): Promise<SalesOrderItem> {
    const id = this.currentSalesOrderItemId++;
    const newItem: SalesOrderItem = { ...item, id };
    this.salesOrderItemsMap.set(id, newItem);
    return newItem;
  }
  
  async updateSalesOrderItem(id: number, itemData: Partial<InsertSalesOrderItem>): Promise<SalesOrderItem | undefined> {
    const existingItem = this.salesOrderItemsMap.get(id);
    if (!existingItem) return undefined;
    
    const updatedItem = { ...existingItem, ...itemData };
    this.salesOrderItemsMap.set(id, updatedItem);
    return updatedItem;
  }
  
  // Initialize with sample data
  private initializeWithSampleData() {
    // Create admin user
    this.createUser({
      username: "admin",
      password: "admin",
      fullName: "John Doe",
      role: "Administrator"
    });
    
    // Create production lines
    this.createProductionLine({
      name: "Line A - Assembly",
      description: "Main assembly line for controllers",
      status: "running",
      efficiency: 84,
      productionRate: 180,
      nextMaintenance: new Date("2023-10-16"),
      currentJobId: 1
    });
    
    this.createProductionLine({
      name: "Line B - Packaging",
      description: "Packaging line for finished products",
      status: "idle",
      efficiency: 72,
      productionRate: 95,
      nextMaintenance: new Date("2023-10-20"),
      currentJobId: 2
    });
    
    this.createProductionLine({
      name: "Line C - Testing",
      description: "Quality control and testing line",
      status: "maintenance",
      efficiency: 0,
      productionRate: 0,
      nextMaintenance: new Date(),
      currentJobId: null
    });
    
    this.createProductionLine({
      name: "Line D - Machining",
      description: "CNC and precision machining line",
      status: "running",
      efficiency: 91,
      productionRate: 137,
      nextMaintenance: new Date("2023-10-25"),
      currentJobId: 3
    });
    
    // Create equipment
    this.createEquipment({
      name: "CNC Machine #103",
      type: "CNC",
      status: "running",
      productionLineId: 4, // Line D
      utilization: 87,
      runtime: 13.2,
      nextMaintenance: new Date("2023-10-25"),
      errorMessage: null
    });
    
    this.createEquipment({
      name: "Robotic Arm #57",
      type: "Robot",
      status: "stopped",
      productionLineId: 1, // Line A
      utilization: 0,
      runtime: 0,
      nextMaintenance: null,
      errorMessage: "Error: Motor overheating"
    });
    
    this.createEquipment({
      name: "Conveyor Line #24",
      type: "Conveyor",
      status: "idle",
      productionLineId: 2, // Line B
      utilization: 42,
      runtime: 6.5,
      nextMaintenance: new Date("2023-10-20"),
      errorMessage: null
    });
    
    // Create work orders
    this.createWorkOrder({
      orderId: "WO-2023-10742",
      product: "Model X15 Controller",
      quantity: 1500,
      status: "in-progress",
      startDate: new Date("2023-10-10"),
      dueDate: new Date("2023-10-15"),
      progress: 68,
      assignedLineId: 1
    });
    
    this.createWorkOrder({
      orderId: "WO-2023-10756",
      product: "Sensor Pack B200",
      quantity: 750,
      status: "pending",
      startDate: new Date("2023-10-11"),
      dueDate: new Date("2023-10-18"),
      progress: 23,
      assignedLineId: 2
    });
    
    this.createWorkOrder({
      orderId: "WO-2023-10761",
      product: "M3 Connector Assembly",
      quantity: 3200,
      status: "in-progress",
      startDate: new Date("2023-10-12"),
      dueDate: new Date("2023-10-20"),
      progress: 42,
      assignedLineId: 4
    });
    
    this.createWorkOrder({
      orderId: "WO-2023-10773",
      product: "PCB Revision 2.4",
      quantity: 400,
      status: "scheduled",
      startDate: new Date("2023-10-14"),
      dueDate: new Date("2023-10-22"),
      progress: 0,
      assignedLineId: null
    });
    
    // Create production metrics
    const today = new Date();
    this.createProductionMetric({
      date: today,
      lineId: 1,
      oee: 78.3,
      productionRate: 180,
      qualityRate: 96.7,
      downtime: 42,
      unitsProduced: 4320
    });
    
    this.createProductionMetric({
      date: today,
      lineId: 2,
      oee: 72.1,
      productionRate: 95,
      qualityRate: 95.2,
      downtime: 60,
      unitsProduced: 2280
    });
    
    this.createProductionMetric({
      date: today,
      lineId: 4,
      oee: 91.4,
      productionRate: 137,
      qualityRate: 98.1,
      downtime: 25,
      unitsProduced: 3288
    });
    
    // Create inventory items
    this.createInventoryItem({
      name: "PCB Base Board",
      sku: "PCB-001",
      category: "Electronics",
      quantity: 2500,
      reorderLevel: 500,
      unitCost: 4.75,
      location: "Warehouse A, Shelf 3"
    });
    
    this.createInventoryItem({
      name: "Connector Type B",
      sku: "CON-002",
      category: "Components",
      quantity: 5000,
      reorderLevel: 1000,
      unitCost: 0.25,
      location: "Warehouse A, Shelf 5"
    });
    
    this.createInventoryItem({
      name: "Sensor Module",
      sku: "SEN-003",
      category: "Electronics",
      quantity: 750,
      reorderLevel: 200,
      unitCost: 12.50,
      location: "Warehouse B, Shelf 2"
    });
    
    this.createInventoryItem({
      name: "Steel Enclosure",
      sku: "ENC-004",
      category: "Housing",
      quantity: 1200,
      reorderLevel: 400,
      unitCost: 3.75,
      location: "Warehouse C, Shelf 1"
    });
    
    // Create customers
    const customer1 = this.createCustomer({
      name: "Acme Industries",
      contactPerson: "John Smith",
      email: "john.smith@acme.com",
      phone: "555-123-4567",
      address: "123 Main St",
      city: "New York",
      state: "NY",
      zipCode: "10001",
      notes: "Premium client with long-term contract",
      customerSince: new Date("2020-01-15")
    });
    
    const customer2 = this.createCustomer({
      name: "TechSolutions Inc.",
      contactPerson: "Sarah Johnson",
      email: "sjohnson@techsolutions.com",
      phone: "555-987-6543",
      address: "456 Tech Blvd",
      city: "San Francisco",
      state: "CA",
      zipCode: "94105",
      notes: "Interested in new product line",
      customerSince: new Date("2021-03-22")
    });
    
    const customer3 = this.createCustomer({
      name: "Global Manufacturing Ltd.",
      contactPerson: "Michael Chen",
      email: "mchen@globalmfg.com",
      phone: "555-555-5555",
      address: "789 Industry Ave",
      city: "Chicago",
      state: "IL",
      zipCode: "60601",
      notes: "International shipping requirements",
      customerSince: new Date("2019-07-10")
    });
    
    // Create products
    const product1 = this.createProduct({
      name: "Model X15 Controller",
      sku: "CTRL-X15",
      description: "Advanced industrial controller with IoT capabilities",
      category: "Controllers",
      unitPrice: 599.99,
      inStock: 350,
      reorderLevel: 50,
      inventoryItemId: 1
    });
    
    const product2 = this.createProduct({
      name: "Sensor Pack B200",
      sku: "SENS-B200",
      description: "Multi-sensor package for environmental monitoring",
      category: "Sensors",
      unitPrice: 249.99,
      inStock: 120,
      reorderLevel: 30,
      inventoryItemId: 3
    });
    
    const product3 = this.createProduct({
      name: "Industrial Enclosure Pro",
      sku: "ENC-PRO",
      description: "Rugged steel enclosure for industrial applications",
      category: "Enclosures",
      unitPrice: 149.99,
      inStock: 200,
      reorderLevel: 50,
      inventoryItemId: 4
    });
    
    // Create sales orders
    const order1 = this.createSalesOrder({
      orderNumber: "SO-2025-1001",
      customerId: customer1.id,
      status: "completed",
      orderDate: new Date("2025-02-15"),
      deliveryDate: new Date("2025-02-25"),
      totalAmount: 5999.90,
      paymentStatus: "paid",
      notes: "Repeat order from satisfied customer",
      shippingAddress: "123 Main St, New York, NY 10001",
      billingAddress: "123 Main St, New York, NY 10001",
      shippingMethod: "Express Freight",
      assignedToWorkOrderId: 1
    });
    
    const order2 = this.createSalesOrder({
      orderNumber: "SO-2025-1002",
      customerId: customer2.id,
      status: "processing",
      orderDate: new Date("2025-03-01"),
      deliveryDate: new Date("2025-03-15"),
      totalAmount: 2999.85,
      paymentStatus: "pending",
      notes: "Customer requested additional documentation",
      shippingAddress: "456 Tech Blvd, San Francisco, CA 94105",
      billingAddress: "456 Tech Blvd, San Francisco, CA 94105",
      shippingMethod: "Standard Shipping",
      assignedToWorkOrderId: 2
    });
    
    const order3 = this.createSalesOrder({
      orderNumber: "SO-2025-1003",
      customerId: customer3.id,
      status: "pending",
      orderDate: new Date("2025-03-10"),
      deliveryDate: new Date("2025-03-30"),
      totalAmount: 8749.65,
      paymentStatus: "unpaid",
      notes: "International shipping requirements to be confirmed",
      shippingAddress: "789 Industry Ave, Chicago, IL 60601",
      billingAddress: "789 Industry Ave, Chicago, IL 60601",
      shippingMethod: "International Freight",
      assignedToWorkOrderId: 3
    });
    
    // Create sales order items
    this.createSalesOrderItem({
      salesOrderId: order1.id,
      productId: product1.id,
      quantity: 10,
      unitPrice: 599.99,
      discount: 0,
      total: 5999.90
    });
    
    this.createSalesOrderItem({
      salesOrderId: order2.id,
      productId: product2.id,
      quantity: 12,
      unitPrice: 249.99,
      discount: 0,
      total: 2999.88
    });
    
    this.createSalesOrderItem({
      salesOrderId: order3.id,
      productId: product1.id,
      quantity: 8,
      unitPrice: 599.99,
      discount: 50,
      total: 4749.92
    });
    
    this.createSalesOrderItem({
      salesOrderId: order3.id,
      productId: product3.id,
      quantity: 20,
      unitPrice: 149.99,
      discount: 0,
      total: 2999.80
    });
    
    this.createSalesOrderItem({
      salesOrderId: order3.id,
      productId: product2.id,
      quantity: 4,
      unitPrice: 249.99,
      discount: 0,
      total: 999.96
    });
  }
}

export const storage = new MemStorage();
