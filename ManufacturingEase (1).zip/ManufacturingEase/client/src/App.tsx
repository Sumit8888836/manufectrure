import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import MainLayout from "@/components/layout/MainLayout";
import Dashboard from "@/pages/dashboard";
import ProductionLines from "@/pages/production-lines";
import Equipment from "@/pages/equipment";
import Inventory from "@/pages/inventory";
import WorkOrders from "@/pages/work-orders";
import Scheduling from "@/pages/scheduling";
import Reports from "@/pages/reports";
import Sales from "@/pages/sales";

function Router() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/production-lines" component={ProductionLines} />
        <Route path="/equipment" component={Equipment} />
        <Route path="/inventory" component={Inventory} />
        <Route path="/work-orders" component={WorkOrders} />
        <Route path="/scheduling" component={Scheduling} />
        <Route path="/reports" component={Reports} />
        <Route path="/sales" component={Sales} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
