import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function NotFound() {
  const [_, setLocation] = useLocation();
  
  useEffect(() => {
    // Try to recover path from session storage (if redirected)
    const redirectPath = sessionStorage.getItem('redirect_path');
    if (redirectPath) {
      sessionStorage.removeItem('redirect_path');
      // Don't immediately redirect to avoid loops
      console.log("Found redirect path:", redirectPath);
    }
  }, []);

  const goHome = () => {
    setLocation('/');
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md mx-4 shadow-lg">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center text-center">
            <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">404 Page Not Found</h1>
            <p className="text-gray-600 mb-6">
              The page you are looking for doesn't exist or has been moved.
            </p>
            
            <Button onClick={goHome} size="lg" className="w-full">
              Return to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
