import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { FilterIcon, RefreshCcw, PlusCircle, FileTextIcon, Download } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { InventoryItem } from "@shared/schema";

export default function Inventory() {
  // Fetch inventory items
  const { data: inventoryItems, isLoading } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory'],
  });
  
  // Helper function to determine inventory status
  const getInventoryStatus = (quantity: number, reorderLevel: number | null) => {
    if (!reorderLevel) return "normal";
    if (quantity <= 0) return "out-of-stock";
    if (quantity <= reorderLevel) return "low";
    return "normal";
  };
  
  // Helper function to get badge class for status
  const getStatusBadgeClass = (status: string) => {
    return status === "normal" ? "bg-green-100 text-green-800" :
           status === "low" ? "bg-yellow-100 text-yellow-800" :
           "bg-red-100 text-red-800";
  };
  
  // Helper function to format status text
  const formatStatus = (status: string) => {
    return status === "normal" ? "Normal" :
           status === "low" ? "Low Stock" :
           "Out of Stock";
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Inventory Management</h1>
          <p className="text-gray-500">Track and manage all inventory items</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <FileTextIcon size={16} className="mr-2" />
            Generate Report
          </Button>
          <Button>
            <PlusCircle size={16} className="mr-2" />
            Add Item
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Filter Inventory</CardTitle>
          <CardDescription>
            Use the filters below to find specific inventory items
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="w-full sm:w-auto">
              <Label htmlFor="search">Search</Label>
              <Input id="search" placeholder="Search by name or SKU" className="mt-1" />
            </div>
            <div className="w-full sm:w-auto">
              <Label htmlFor="category-filter">Category</Label>
              <Select>
                <SelectTrigger className="mt-1 w-full" id="category-filter">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  <SelectItem value="electronics">Electronics</SelectItem>
                  <SelectItem value="components">Components</SelectItem>
                  <SelectItem value="housing">Housing</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full sm:w-auto">
              <Label htmlFor="status-filter">Status</Label>
              <Select>
                <SelectTrigger className="mt-1 w-full" id="status-filter">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="low">Low Stock</SelectItem>
                  <SelectItem value="out-of-stock">Out of Stock</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full sm:w-auto mt-auto">
              <Button variant="outline" className="w-full sm:w-auto">
                <FilterIcon size={16} className="mr-2" />
                Apply Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-gray-500">
          {inventoryItems?.length} items found
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download size={16} className="mr-1" />
            Export
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCcw size={16} className="mr-1" />
            Refresh
          </Button>
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">SKU</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Name</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Category</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Quantity</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Status</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Reorder Level</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Unit Cost</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Location</TableHead>
                  <TableHead className="bg-blue-50 text-blue-600 font-medium">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8">
                      Loading inventory data...
                    </TableCell>
                  </TableRow>
                ) : inventoryItems?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8">
                      No inventory items found. Add your first item to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  inventoryItems?.map((item) => {
                    const status = getInventoryStatus(item.quantity, item.reorderLevel);
                    return (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">{item.sku}</TableCell>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell className="font-medium">{item.quantity.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeClass(status)} variant="outline">
                            {formatStatus(status)}
                          </Badge>
                        </TableCell>
                        <TableCell>{item.reorderLevel?.toLocaleString() || 'N/A'}</TableCell>
                        <TableCell>${item.unitCost?.toFixed(2) || 'N/A'}</TableCell>
                        <TableCell>{item.location || 'N/A'}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="material-icons text-blue-600">edit</span>
                            </Button>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="material-icons text-blue-600">visibility</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
