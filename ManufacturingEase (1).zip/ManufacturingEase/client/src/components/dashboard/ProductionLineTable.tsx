import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { formatDateShort } from "@/lib/utils/date-utils";
import { ProductionLine } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { Eye } from "lucide-react";
import { Link } from "wouter";

interface ProductionLineTableProps {
  productionLines: ProductionLine[];
  isLoading?: boolean;
}

export default function ProductionLineTable({ productionLines, isLoading = false }: ProductionLineTableProps) {
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg overflow-hidden shadow animate-pulse">
        <div className="h-10 bg-gray-200 m-4"></div>
        <div className="h-96 bg-gray-100 m-4"></div>
      </div>
    );
  }
  
  // Helper to get status indicator class
  const getStatusClass = (status: string) => {
    return status === "running" ? "bg-green-600" :
           status === "idle" ? "bg-orange-500" :
           status === "maintenance" ? "bg-purple-600" :
           "bg-red-600";
  };
  
  // Helper to format status
  const formatStatus = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };
  
  // Helper to get efficiency color
  const getEfficiencyColor = (efficiency: number | null) => {
    if (efficiency === null || efficiency === 0) return "bg-gray-400";
    if (efficiency >= 90) return "bg-green-600";
    if (efficiency >= 80) return "bg-green-500";
    if (efficiency >= 70) return "bg-yellow-500";
    return "bg-orange-500";
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Line</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Status</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Current Job</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Efficiency</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Production Rate</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Next Maintenance</TableHead>
              <TableHead className="bg-blue-50 text-blue-600 font-medium">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {productionLines.map((line) => (
              <TableRow key={line.id} className="hover:bg-gray-50">
                <TableCell className="font-medium">{line.name}</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <span className={`w-3 h-3 rounded-full mr-2 ${getStatusClass(line.status)}`}></span>
                    <span>{formatStatus(line.status)}</span>
                  </div>
                </TableCell>
                <TableCell>{line.currentJobId ? `WO-${line.currentJobId}` : '--'}</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <span className="font-medium">{line.efficiency ? `${line.efficiency}%` : '0%'}</span>
                    <div className="ml-2 w-16">
                      <Progress value={line.efficiency || 0} className="h-1 bg-gray-200">
                        <div 
                          className={`h-1 ${getEfficiencyColor(line.efficiency)} rounded-full`} 
                          style={{ width: `${line.efficiency || 0}%` }}>
                        </div>
                      </Progress>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{line.productionRate ? `${line.productionRate} units/hr` : '0 units/hr'}</TableCell>
                <TableCell>{line.nextMaintenance ? formatDateShort(line.nextMaintenance) : 'Not scheduled'}</TableCell>
                <TableCell>
                  <Link href={`/production-lines/${line.id}`}>
                    <Button variant="ghost" size="icon" className="text-blue-600 hover:text-blue-800">
                      <Eye size={18} />
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
