import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface DataPoint {
  name: string;
  lineA: number;
  lineB: number;
  lineD: number;
}

interface ProductionChartProps {
  title?: string;
  data: DataPoint[];
}

export default function ProductionChart({ title = "Production Trends", data }: ProductionChartProps) {
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month">("week");
  
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium text-gray-800">{title}</CardTitle>
          <div className="flex">
            <Button 
              variant={timeRange === "day" ? "default" : "outline"}
              size="sm"
              className="text-sm mr-2"
              onClick={() => setTimeRange("day")}
            >
              Day
            </Button>
            <Button 
              variant={timeRange === "week" ? "default" : "outline"}
              size="sm"
              className="text-sm mr-2"
              onClick={() => setTimeRange("week")}
            >
              Week
            </Button>
            <Button 
              variant={timeRange === "month" ? "default" : "outline"}
              size="sm"
              className="text-sm"
              onClick={() => setTimeRange("month")}
            >
              Month
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="lineA"
                name="Line A"
                stroke="#1976D2"
                strokeWidth={2}
                activeDot={{ r: 8 }}
                fill="#1976D2"
              />
              <Line
                type="monotone"
                dataKey="lineB"
                name="Line B"
                stroke="#388E3C"
                strokeWidth={2}
                activeDot={{ r: 8 }}
                fill="#388E3C"
              />
              <Line
                type="monotone"
                dataKey="lineD"
                name="Line D"
                stroke="#F57C00"
                strokeWidth={2}
                activeDot={{ r: 8 }}
                fill="#F57C00"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
