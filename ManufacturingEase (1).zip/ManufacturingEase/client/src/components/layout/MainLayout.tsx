import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { useSidebar } from "@/lib/hooks/use-sidebar";
import { useLocation } from "wouter";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { collapsed } = useSidebar();
  const [location] = useLocation();
  
  // Get the title based on the current route
  const getTitle = () => {
    if (location === "/") return "Dashboard";
    return location.slice(1).split("-").map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(" ");
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <Sidebar />
      <div className={`flex flex-col flex-1 transition-all duration-300 ${collapsed ? 'ml-16' : 'ml-64'}`}>
        <Header title={getTitle()} />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
