import { Link, useLocation } from "wouter";
import { useSidebar } from "@/lib/hooks/use-sidebar";

const menuItems = [
  { path: "/", label: "Dashboard", icon: "dashboard" },
  { path: "/production-lines", label: "Production Lines", icon: "speed" },
  { path: "/equipment", label: "Equipment", icon: "settings" },
  { path: "/inventory", label: "Inventory", icon: "inventory_2" },
  { path: "/work-orders", label: "Work Orders", icon: "assignment" },
  { path: "/scheduling", label: "Scheduling", icon: "calendar_today" },
  { path: "/sales", label: "Sales", icon: "shopping_cart" },
  { path: "/reports", label: "Reports", icon: "bar_chart" },
];

export default function Sidebar() {
  const [location] = useLocation();
  const { collapsed, toggleSidebar } = useSidebar();

  return (
    <div className={`fixed inset-y-0 left-0 z-10 flex flex-col flex-shrink-0 transition-all duration-300 bg-zinc-800 text-white ${collapsed ? 'w-16' : 'w-64'}`}>
      <div className="flex items-center justify-between p-4 border-b border-zinc-700">
        <div className="flex items-center">
          <span className="material-icons mr-3">precision_manufacturing</span>
          {!collapsed && <span className="font-medium text-lg">ManufactPro</span>}
        </div>
        <button onClick={toggleSidebar} className="text-white focus:outline-none">
          <span className="material-icons">menu</span>
        </button>
      </div>
      <nav className="flex-1 mt-4">
        <ul>
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path}>
                <a className={`flex items-center px-4 py-3 hover:bg-blue-800 ${location === item.path ? 'bg-blue-700' : ''}`}>
                  <span className="material-icons mr-3">{item.icon}</span>
                  {!collapsed && <span>{item.label}</span>}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* For external CSS dependencies */}
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    </div>
  );
}
